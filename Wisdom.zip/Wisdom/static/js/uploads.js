var vm = new Vue({
    el: '#app',
    // 修改Vue变量的读取语法，避免和django模板语法冲突
    delimiters: ['[[', ']]'],
    data: {
        
        show_menu:false,
        is_login:true,
        username:''
    },
    mounted(){
        this.username=getCookie('username');
        this.is_login=getCookie('is_login');
    },
    methods: {
        //显示下拉菜单
        show_menu_click:function(){
            this.show_menu = !this.show_menu ;
        },
    }
});


const input = document.getElementById('fileInput');
const preview = document.querySelector('.preview');
const title = document.getElementById('title');

const secretkey = document.getElementById('secretKey')
title.focus()
input.style.opacity = 0;

input.addEventListener('change', updatefileDisplay);

function updatefileDisplay() {
    while (preview.firstChild) {
        preview.removeChild(preview.firstChild);
    }

    const curFiles = input.files;
    if (curFiles.length === 0) {
        const para = document.createElement('p');
        para.textContent = '没有选择上传文件';
        preview.appendChild(para);
    } else {
        const list = document.createElement('ul');
        preview.appendChild(list);

        for (const file of curFiles) {
            const listItem = document.createElement('li');
            const para = document.createElement('p');
            para.textContent = `文件： ${file.name}, 大小 ${returnFileSize(file.size)}.`;
            listItem.appendChild(para);
            title.value = file.name
            title.focus()
            list.appendChild(listItem);
        }
       
    }
    
    
}

$(document).ready(function () {
   $("#submit").click(function(event){
       event.preventDefault();
   });
$('#submit').click(function () {


   let context = '';
   let reader = new FileReader();
   reader.readAsText(input.files[0]);
   reader.onload = function () {
  
       context = this.result;
   
       console.log('context:' + context);

       const secretKey = SimpleCrypto.generateRandom(256);
       const secretKey_word = 'secretkey';
       secretkey.value = secretKey;
       const simpleCrypto = new SimpleCrypto(secretKey);
   
       const plainText = context;
       const cipherText = simpleCrypto.encrypt(plainText);
       console.log("Encryption process...");
       console.log("Plain Text    : " + plainText);
       console.log("Cipher Text   : " + cipherText);
       const decipherText = simpleCrypto.decrypt(cipherText);
       console.log("... and then decryption...");
       console.log("Decipher Text : " + decipherText);
       console.log("... done.");
       words = $('#desc').val().trim().split(/\s+/);
       const wordsCrypto = new SimpleCrypto(secretKey_word);
       console.log(words);
       _words = [];
       for (i = 0; i < words.length; i++){
           _words.push(wordsCrypto.encrypt(words[i]));
       }
       
        
       console.log(_words);
       for (i = 0; i < _words.length; i++){
            console.log(wordsCrypto.decrypt(_words[i]));
       }
      
       
      
       $.ajax({
           type: 'POST',
           url: '',
           cache: false,
         
           data: {
                traditional:true,
               'title': $('#title').val(),
               'filename': input.files[0].name,
               'filecontent': cipherText,
               'filetype':input.files[0].type,
               'category': $('#category').val(),
               'words':_words.toString(),
               'password':secretKey
           },
           success:function() {
        //成功返回{'res':1},失败{'res':0}
       //成功跳转到books页面
            location.href='/'
    
        }
  
       })
   }
});
});
function returnFileSize(number) {
    if (number < 1024) {
        return number + 'bytes';
    } else if (number >= 1024 && number < 1048576) {
        return (number / 1024).toFixed(1) + 'KB';
    } else if (number >= 1048576) {
        return (number / 1048576).toFixed(1) + 'MB';
    }
}

