var vm = new Vue({
    el: '#app',
    // 修改Vue变量的读取语法，避免和django模板语法冲突
    delimiters: ['[[', ']]'],
    data: {
      
        show_menu:false,
        is_login:true,
        username:''
    },
    mounted(){
        this.username=getCookie('username');
        this.is_login=getCookie('is_login');
    },
    methods: {
        //显示下拉菜单
        show_menu_click:function(){
            this.show_menu = !this.show_menu ;
        },
    }
});

$(document).ready(function(){
    $('#phone').on('input propertychange', function(){
      let phone = $.trim($(this).val());
      if(phone==""){
          $("#msg").html("");
          $("#btn").attr("disabled",false);
      }else{
        let mobile = /^(13[0-9]|14[5|7]|15[0|1|2|3|4|5|6|7|8|9]|18[0|1|2|3|5|6|7|8|9])\d{8}$/
        if(mobile.test(phone)){
            $("#msg").html("<font color='green'>手机号格式正确</font>");
            $("#btn").attr("disabled",false);//使按钮无法点击
        }else{
          $("#msg").html("<font color='red'>手机号不正确</font>");
          $("#btn").attr("disabled",true);
        }
      }
    })
})