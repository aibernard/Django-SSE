
var vm = new Vue({
    el: '#app',
    // 修改Vue变量的读取语法，避免和django模板语法冲突
    delimiters: ['[[', ']]'],
    data: {
        queryString:"", // 查询字符串
        isInfo:false, // 是否显示提示信息
        infoText:"", // 要显示的提示信息
        show_menu:false,
        is_login:false,
        username:''
    },
    mounted(){
        this.username=getCookie('username');
        this.is_login=getCookie('is_login');
    },
    methods: {
        //显示下拉菜单
        show_menu_click:function(){
            this.show_menu = !this.show_menu ;
        },
        search:function(){
            if(this.queryString === ""){  
                this.infoText = "输入的内容不能为空！";                  
                this.isInfo = true;
                let that = this;
                // 1200毫秒之后关闭提示信息
                setTimeout(function(){
                    that.isInfo = false;
                }, 1200);
            } else {
                const secretKey_word = 'secretkey';
                const wordsCrypto = new SimpleCrypto(secretKey_word);
                let queword = this.queryString.trim().split(/\s+/);
                    let keys = '';
                    for (i = 0; i < words.length; i++){
                        for (j = 0; j < queword.length; j++){
                            if (wordsCrypto.decrypt(words[i]) == queword[j]) {
                                keys +=encodeURIComponent(words[i])+'+'
                            }
                            else {
                                keys +=''
                            }
                        }
                    }
                    if (keys == '') {
                        window.alert('无结果')
                    }
                    else {
                         window.open(search_url+ "?tw=" + keys,'查询结果');
                    }
            }
        }
    },
    
});

function load_file(id){
    console.log(id)
    $.ajax({
        type: 'GET',
        url: download_url,
        data: {
           'id':id
        },
        success: function (result1, result2, ResponseHeader) {
            const secretKey_word = ResponseHeader.getResponseHeader('password');
            const wordsCrypto = new SimpleCrypto(secretKey_word);
            console.log(result2);
            ResponseHeader.responseText=wordsCrypto.decrypt(result1)
            console.log(ResponseHeader.getAllResponseHeaders());
            filename = ResponseHeader.getResponseHeader('Content-Disposition').split('=')[1];
            console.log(filename)
            let a = document.createElement('a');
            a.href = 'data:text/txt;charset=utf-8,' + encodeURIComponent(ResponseHeader.responseText);
            a.download = filename;
            a.click();
            a.remove();
     }

    })
}