 window.onload = function(){
        // 时钟代码
        let year_text = document.getElementById("year");
        let month_text = document.getElementById("month");
        let day_text = document.getElementById("day");
        let hour_text = document.getElementById("hour");
        let minute_text = document.getElementById("minute");
        let second_text = document.getElementById("second");
        let ul = document.getElementById('words');
        let timer = setInterval(function(){
            let date = new Date();
            let year = date.getFullYear();
            let month = date.getMonth();
            let day = date.getDate();
            let hour = date.getHours();
            let minute = date.getMinutes();
            let second = date.getSeconds();
            year_text.innerHTML = year;
            month_text.innerHTML = (month + 1);
            day_text.innerHTML = day;
            hour_text.innerHTML = hour + ":";
            minute_text.innerHTML = minute + ":";
            second_text.innerHTML = second;
        }, 100);

        // 设置input框自动获取焦点
        let searchInput = document.getElementById("searchInput");
        searchInput.focus();
        
     const secretKey_word = 'secretkey';
     const wordsCrypto = new SimpleCrypto(secretKey_word);
     for (i = 0; i < words.length; i++){
         word = wordsCrypto.decrypt(words[i]);
         let li = document.createElement('li');
         li.className='key'
         li.innerHTML = word;
         ul.appendChild(li);
         
     }    
    };

const vm = new Vue({
        el:"#app", 
        delimiters: ['[[', ']]'],
        data:{
            queryString:"", // 查询字符串
            isInfo:false, // 是否显示提示信息
            infoText:"", // 要显示的提示信息
            show_menu:false,
            is_login:false,
            username:''
        },

    mounted(){
        this.username=getCookie('username');
        this.is_login=getCookie('is_login');
    },

    methods: { 
            show_menu_click:function(){
            this.show_menu = !this.show_menu ;
            },
            // 按下enter键或点击搜索图标进行搜索
        search: function () {
            const secretKey_word = 'secretkey';
            const wordsCrypto = new SimpleCrypto(secretKey_word);
                if(this.queryString === ""){  
                    this.infoText = "输入的内容不能为空！";                  
                    this.isInfo = true;
                    let that = this;
                    // 1200毫秒之后关闭提示信息
                    setTimeout(function(){
                        that.isInfo = false;
                    }, 1200);
                } else {
                    let queword = this.queryString.trim().split(/\s+/);
                    let keys = '';
                    for (i = 0; i < words.length; i++){
                        for (j = 0; j < queword.length; j++){
                            if (wordsCrypto.decrypt(words[i]) == queword[j]) {
                                keys +=encodeURIComponent(words[i])+'+'
                            }
                            else {
                                keys +=''
                            }
                        }
                    }
                    if (keys == '') {
                        window.alert('无结果')
                    }
                    else {
                         window.open(search_url+ "?tw=" + keys);
                    }
                   
                }
            }
        },
    });