var vm = new Vue({
    el: '#app1',
    // 修改Vue变量的读取语法，避免和django模板语法冲突
    delimiters: ['[[', ']]'],
    data: {
      
        show_menu:false,
        is_login:true,
        username:''
    },
    mounted(){
        this.username=getCookie('username');
        this.is_login=getCookie('is_login');
    },
    methods: {
        //显示下拉菜单
        show_menu_click:function(){
            this.show_menu = !this.show_menu ;
      },
      on_submit:function () {
            
      }
    }
});


const signInBtn = document.getElementById("signIn");
const signUpBtn = document.getElementById("signUp");
const container = document.querySelector(".container_login");
let password = document.getElementById("id_password");
let confirm = document.getElementById("id_confirm");


signInBtn.addEventListener("click", () => {
  container.classList.remove("right-panel-active");
});

signUpBtn.addEventListener("click", () => {
  container.classList.add("right-panel-active");
});




$(document).ready(function(){
        $('#id_email').on('input propertychange', function(){
          let email = $.trim($(this).val());
          if(email==""){
            $("#msg_email").html("<font color='red'>邮箱不能为空</font>");
          }else{
            let mail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
            if(mail.test(email)){
                $("#msg_email").html("<font color='green'>邮箱格式正确</font>");
                $("#btn_register").attr("disabled",false); //使按钮无法点击
            }else{
              $("#msg_email").html("<font color='red'>邮箱格式错误</font>");
              $("#btn_register").attr("disabled",true);
            }
          }
        })
})

$(document).ready(function(){
        $('#email').on('input propertychange', function(){
          let email = $.trim($(this).val());
          if(email==""){
            $("#msg_logemail").html("<font color='red'>邮箱不能为空</font>");
          }else{
            let mail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
            if(mail.test(email)){
                $("#msg_logemail").html("<font color='green'>邮箱格式正确</font>");
                $("#btn_login").attr("disabled",false); //使按钮无法点击
            }else{
              $("#msg_logemail").html("<font color='red'>邮箱格式错误</font>");
              $("#btn_login").attr("disabled",true);
            }
          }
        })
})


$(document).ready(function(){
        $('#id_password').on('input propertychange', function() {        
                               //input propertychange即实时监控键盘输入包括粘贴
                                var pwd = $.trim($(this).val());
                               //获取this，即ipwd的val()值，trim函数的作用是去除空格
                                var rpwd = $.trim($('#id_confirm').val());
                                  if(rpwd!=""){
                                          if(pwd==""&&rpwd==""){
                  //若都为空，则提示密码不能为空，为了用户体验（在界面上用required同时做了处理）
                                                $("#msg_pwd").html("<font color='red'>密码不能为空</font>");
                                          }
                                          else{
                                                              if(pwd==rpwd){//相同则提示密码匹配
                                                                $("#msg_pwd").html("<font color='green'>两次密码匹配通过</font>");
                                                                $("#btn_register").attr("disabled",false); //使按钮无法点击
                                                                  }else{//不相同则提示密码匹配
                                                                  $("#msg_pwd").html("<font color='red'>两次密码不匹配</font>");
                                                                $("#btn_register").attr("disabled",true);
                                          }
                                        }}
                      })
})
 
//由于是两个输入框，所以进行两个输入框的几乎相同的判断
$(document).ready(function(){
                                            $('#id_confirm').on('input propertychange', function() {
                                                              var pwd = $.trim($(this).val());
                                                              var rpwd = $.trim($("#id_password").val());
                                                              if(pwd==""&&rpwd==""){
                                                                              $("#msg_pwd").html("<font color='red'>密码不能为空</font>");
                                                                   }
                                                              else{
                                                                                    if(pwd==rpwd){
                                                                                    $("#msg_pwd").html("<font color='green'>两次密码匹配通过</font>");
                                                                                    $("#btn_register").attr("disabled",false);
                                                                                    }else{
                                                                                    $("#msg_pwd").html("<font color='red'>两次密码不匹配</font>");
                                                                                    $("#btn_register").attr("disabled",true);
                                                  }
                                                                          }
                                })
            })
