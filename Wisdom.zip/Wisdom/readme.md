# 多关键词可搜索加密



## 介绍

1. 用户建立密文系统，分享共享信息使得其他人可以搜索文件

2. 支持加密状态下多个关键词返回结果

## 文件说明

```
├─.idea   #相关配置文件
│  ├─dataSources
│  └─inspectionProfiles
├─media		#文件上传目录
│  └─FileRecv
│      └─20210623
├─myWeb	#网站主页视图、模型、url设计
│  ├─migrations
│  │  └─__pycache__
│  └─__pycache__
├─static	#网站静态资源
│  ├─css
│  ├─imgs
│  └─js
├─templates	#html模板
│  ├─myweb
│  └─users
├─tools		#自定义python模块
│  └─__pycache__
├─users		#用户网页视图、模型、url设计
│  ├─migrations
│  │  └─__pycache__
│  └─__pycache__
└─Wisdom	#Django项目的相关设置
    └─__pycache__
```

## 本地测试

1. 运行django服务器

    ```
    $ pip install -r requirements.txt
    
    $ python manage.py makemigrations
    $ python manage.py migrate
    $ python manage.py runserver
    ```

3. 打开网址 http://127.0.0.1:8080 进行访问

> 

### 注意的点

现有的账号：

管理员账号：root@163.com  pwd：root

普通用户：bernard@163.com pwd：123456

上传文件命名尽量不要用中文，因为下载文件名可能会出错

目前仅支持文本文件		其他文件不支持
