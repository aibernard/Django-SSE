from django.db.models import indexes
from django.shortcuts import render, redirect
from django.http import FileResponse, response
from numpy.core.arrayprint import printoptions
from users.models import Users
from myWeb.models import File, FileCategory,Index
from django.views import View
from django.urls import reverse
from django.utils.encoding import escape_uri_path  # 用于解决中文命名文件乱码问题
from tools.essential import getInMemoryUploadedFile_bytes
from tools.encrypt import getPassword,encrypt_aes,decrypt_aes,pad,get_md5_value
from tools.tf_idf import tf_idf
from django.conf import settings
import chardet
import os
import json
import base64
import logging

# Create your views here.
logger = logging.getLogger('django')
DIR = os.path.join(settings.BASE_DIR,'media/')

# home 页面

# 向量相乘
def vector_dot(vector1,vector2):
  if len(vector1) != len(vector2):
    return "len_err"
  return sum([vector1[x] * vector2[x] for x in range(len(vector1))])

# 解密文件
def decrypt_file(filename,password):
  f = open(filename,"rb")
  c_data = f.read()
  f.close()
  # print(password)
  data = decrypt_aes(c_data,password)
  encoding = chardet.detect(data)["encoding"]
  # 如果解密之后找不到编码的格式，那么说明密钥错误
  if encoding == None:
    return False
  # print(encoding)
  return data.decode(encoding)

class Index_View(View):
	def get(self, request):
		word=[]
		indexs = Index.objects.all()
		if(indexs.exists()==False):
			return render(request, 'myweb/index.html',context={'words':word})
		else:
			
			data_lib = []
			for index in indexs:
				lists=index.word
				# 这里需要全部变成小写，防止搜索时大小写不匹配的问题
				data_lib.append(lists)
			

			return render(request, 'myweb/index.html',context={'words':data_lib})

#
class SearchView(View):
	def get(self,request):
		# aes_secret = bytes([int(x) for x in request.POST["aes_secret"].split(",")])
		tw = request.GET.get('tw')
		print('最初：'+tw)
		tw = [x for x in tw.split(" ")]
		print(tw)
		indexs=Index.objects.all()
		search_files = []
		words=[]
		for index in indexs:
			key = index.word
			words.append(index.word)
			for x in tw:
				if(x == key):
					search_files.append(index.File_ID)
			
		print(search_files)
		return render(request,'myweb/downloads.html',context={'files':search_files,'words':words})



class DownloadView(View):
	def get(self,request):
		id=request.GET.get('id')
		try:
			file=File.objects.get(id=id)
			fileroad=os.path.join(DIR,str(file.file))
			filename=str(file.file).split('/')[-1]
		except File.DoesNotExist:
			return render(reverse('home:404'))
		else:
			file.total_loads +=1
			file.save()
			try:
				f = open(fileroad,"r")
				c_data = f.read()
				response = FileResponse(c_data)
				response['password']=file.aes_password
				response['Content-Type']='application/octet-stream'
				response['Content-Disposition'] = 'attachment;filename={0}'.format(escape_uri_path(filename))
				return response

			except:
				return render(reverse('home:404'))



class NotFoundView(View):
	def get(self, request):
		return render(request,'404.html')