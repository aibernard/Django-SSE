from django.contrib import admin
from myWeb.models import File,FileCategory,Index
# Register your models here.
admin.site.register(FileCategory)
admin.site.register(File)
admin.site.register(Index)