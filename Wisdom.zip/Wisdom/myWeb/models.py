from django.db import models
from django.db.models.fields import CharField
from numpy import character
from users.models import Users
from django.utils import timezone

# Create your models here.
class FileCategory(models.Model):
    title = models.CharField(max_length=100,blank=True)
    created=models.DateTimeField(default=timezone.now)
    
    def __str__(self):
        return self.title
    
    class Meta:
        db_table='tb_category'
        verbose_name='类别管理'
        verbose_name_plural=verbose_name

class File(models.Model ):
    author=models.ForeignKey(Users, on_delete=models.CASCADE)
    title=models.CharField(max_length=100,blank=True)
    category=models.ForeignKey(FileCategory, null=True,blank=True,on_delete=models.CASCADE,related_name='article')
    file=models.FileField(upload_to='FileRecv/%Y%m%d',blank=True)
    summary=models.CharField(max_length=500,null=False,blank=False)
   
    md5 = models.CharField(max_length=50,null=False,blank=False,  default='')
    total_loads=models.PositiveIntegerField(default=0)
    created=models.DateField(default=timezone.now)
    aes_password=models.BinaryField(max_length=200, blank=False)
    class Meta:
        db_table='tb_file'
        ordering=('-created',)
        verbose_name='文档管理'
        verbose_name_plural=verbose_name
        
    def __str__(self):
        return self.title

class Index(models.Model):
    word=CharField(max_length=50,blank=True)
    File_ID=models.ForeignKey(File, null=True,blank=True,on_delete=models.CASCADE,related_name='Index')
    created=models.DateField(default=timezone.now)

    
    class Meta:
        db_table='tb_Index'
        ordering=('-created',)
        verbose_name='索引管理'
        verbose_name_plural=verbose_name
        
    def __str__(self):
        return self.word