from django.urls import path, re_path
from myWeb.views import Index_View, SearchView, DownloadView, NotFoundView

urlpatterns = [
	path('', Index_View.as_view(), name='index'),
	path('search/', SearchView.as_view(), name='search'),
	path('downloads/', DownloadView.as_view(), name='downloads'),
	path('404/', NotFoundView.as_view(), name='404')
]