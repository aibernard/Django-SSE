#coding: utf-8
from scipy.sparse import data
from myWeb.models import File
from django.shortcuts import render
from django.http.response import HttpResponseBadRequest, JsonResponse
from users.models import Users
from myWeb.models import File, FileCategory,Index
from django.views import View
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import DatabaseError
from django.conf import settings
import base64
import re
import json
import chardet
import logging
import os
from django.shortcuts import redirect
from django.urls import reverse
from tools.tf_idf import tf_idf
from tools.essential import getInMemoryUploadedFile_bytes
from tools.encrypt import getPassword,encrypt_aes,decrypt_aes,pad,get_md5_value

logger = logging.getLogger('django')


# Create your views here.
class LoginView(View):
    def get(self, request):
        return render(request, 'users/login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        remember = request.POST.get('remember')

        user = authenticate(email=email,password=password)
        if user is None:
            return HttpResponseBadRequest('用户名或密码错误')
        login(request, user)
        response=redirect(reverse('home:index'))
        if remember != 'on':
            request.session.set_expiry(0)
            response.set_cookie('is_login',True)
            response.set_cookie('username',user.username,max_age=14*24*3600)
        else:
            request.session.set_expiry(None)
            response.set_cookie('is_login',True,max_age=1*24*3600)
            response.set_cookie('username',user.username,max_age=1*24*3600)
        
        return response
        


class RegisterView(View):

    def post(self, request):

        email = request.POST.get('id_email')
        username = request.POST.get('id_username')
        password = request.POST.get('id_password')
        
        try:
            user = Users.objects.create_user(email=email, username=username, password=password)
        except DatabaseError as e:
            logger.error(e)
            return HttpResponseBadRequest('注册失败')
        login(request, user)
        response = redirect(reverse('home:index'))
        response.set_cookie('is_login', True)
        response.set_cookie('username', user.username, max_age=1 * 24 * 3600)
        return response

class LogoutView(View):
    def get(self,request):
        logout(request)
        response = redirect(reverse('home:index'))
        response.delete_cookie('is_login')
        return response


class UserCenterView(LoginRequiredMixin,View):
    def get(self,request):
        user=request.user
        context = {
            'username':user.username,
            'email':user.email,
            'mobile':user.mobile,
            'birthday':user.birthday,
            'user_desc':user.user_desc,
            'money':user.money
        }
        return render(request,'users/center.html',context=context)
    def post(self,request):
        user=request.user
        username=request.POST.get('username',request.user)
        user_desc=request.POST.get('desc',user.user_desc)
        mobile=request.POST.get('phone',user.mobile)
        try:
            user.username=username
            user.user_desc=user_desc
            user.mobile=mobile
            user.save()
        except Exception as e:
            logger.error(e)
            return HttpResponseBadRequest('修改失败，请稍后再试')
        response=redirect(reverse('users:center')) 
        response.set_cookie('username',user.username,max_age=14*24*3600)
        
        return response


class loadView(LoginRequiredMixin,View):
    def get(self,request):
        categories=FileCategory.objects.all()
        context={
            'categories':categories
        }
        return render(request, 'users/uploads.html',context) 

    def post(self,request):
        filename=request.POST.get('filename')
        filecontent=request.POST.get('filecontent')
        filetype=request.POST.get('filetype')
        title=request.POST.get('title')
        category_id=request.POST.get('category')
        words=request.POST.getlist('words')
        password=request.POST.get('password')
        words=words[0].split(',')
        print(words)
        by=password.encode()
        print(password+'\n'+by.decode())
        user=request.user
        if not all([filename,title,category_id,words]):
            return HttpResponseBadRequest("缺少参数")
        try:
            category=FileCategory.objects.get(id=category_id)
            
        except Exception as e:
            return HttpResponseBadRequest("没有此分类")

       
        #try:
       
        md5 = get_md5_value(filecontent.encode())
        current_files = File.objects.all()
        for current_file in current_files:
            if current_file.md5 == md5:
                return HttpResponseBadRequest("重复文件")
        file=getInMemoryUploadedFile_bytes(filecontent.encode(),filename)
        obj_file= File.objects.create(
                author=user,
                file=file,
                category=category,
                summary=words,
                title=title,
                aes_password=password.encode(),
                md5=md5
            )
        print(words)
        for word in words:
            index=  Index.objects.create(
                word=word,
                File_ID=obj_file
            )
        # filename=os.path.join(settings.BASE_DIR,str(obj_file.file.file))
        # f = open(filename,"rb")
        # c_data = f.read()
        # f.close()
        # # print(password)
        # data = decrypt_aes(c_data,aes_password)
        # encoding = chardet.detect(data)["encoding"]
        # # 如果解密之后找不到编码的格式，那么说明密钥错误
        # if encoding == None:
        #     return False,False
        # # print(encoding)
        # print('解密后：'+data.decode(encoding),c_data)
        # # except Exception as e:
        # #     logger.error(e)
        # #     return HttpResponseBadRequest("发布失败，请稍后再试")
        
        return redirect(reverse('home:index'))