from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.fields.related import ForeignKey
# Create your models here.

class Users(AbstractUser):
    email = models.EmailField(unique=True,blank=False)
    username = models.CharField(max_length=30,default="")
    mobile = models.CharField(max_length=11,default="")
    user_desc= models.TextField(max_length=500,blank=True,default='这个人什么都没有留下...')
    birthday = models.DateTimeField(auto_now_add=True)
    money = models.DecimalField( max_digits=8, decimal_places=2,default=0.00)
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username','mobile']
 
    #可以修改信息
    class Meta:
        db_table = 'tb_user'
        verbose_name = '用户管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.email